function fetchSchedule() {
    const year = document.getElementById('yearInput').value;
    if (!year) {
        alert("Please enter a year.");
        return;
    }
    const apiUrl = `https://ergast.com/api/f1/${year}.json`;

    fetch(apiUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            displaySchedule(data);
        })
        
}

function displaySchedule(data) {
    const races = data.MRData.RaceTable.Races;
    const scheduleInfo = document.getElementById('scheduleInfo');
    scheduleInfo.innerHTML = `Series: ${data.MRData.series}, Season: ${data.MRData.RaceTable.season}, Total Races: ${races.length}`;

    const scheduleTable = document.getElementById('scheduleTable').getElementsByTagName('tbody')[0];
    scheduleTable.innerHTML = ''; 
    races.forEach(race => {
        const row = scheduleTable.insertRow();
        row.insertCell(0).textContent = race.season;
        row.insertCell(1).textContent = race.round;
        row.insertCell(2).textContent = race.raceName;
        row.insertCell(3).textContent = race.date;
        row.insertCell(4).textContent = race.time ? race.time : 'N/A';
        row.insertCell(5).textContent = race.Circuit.Location.country;
        const linkCell = row.insertCell(6);
        const link = document.createElement('a');
        link.setAttribute('href', race.url);
        link.setAttribute('target', '_blank');
        link.textContent = 'View Race';
        linkCell.appendChild(link);
    });
}
